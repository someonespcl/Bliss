package com.sistra.activities;

import android.animation.Animator;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.sistra.R;
import com.sistra.databinding.ActivityVerificationBinding;

import java.util.Objects;

public class VerificationActivity extends AppCompatActivity {

    private ActivityVerificationBinding verificationBinding;
    private FirebaseUser user;
    private Handler handler = new Handler();
    private Runnable runnable;

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        verificationBinding = ActivityVerificationBinding.inflate(getLayoutInflater());
        setContentView(verificationBinding.getRoot());

        user = FirebaseAuth.getInstance().getCurrentUser();

        String userEmail = getIntent().getStringExtra("email");

        if (userEmail != null) {
            if (user != null && !user.isEmailVerified()) {
                // User is not verified, send verification email
                user.sendEmailVerification().addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        // Verification email sent successfully
                        verificationBinding.verificationText.setText("We have sent an verification email to " + userEmail);
                        checkEmailVerificationStatus();
                    } else {
                        // Verification email sending failed
                        verificationBinding.verificationText.setText("Failed to send verification email for the following reason: " + Objects.requireNonNull(task.getException()).getMessage());
                    }
                });
            }
        }
    }

    private void checkEmailVerificationStatus() {
        runnable = new Runnable() {
            @Override
            public void run() {
                user.reload().addOnCompleteListener(task -> {
                    if (user.isEmailVerified()) {
                        verificationBinding.verificationText.setText("Email verified successfully");
                        verificationBinding.verificationStatusAnim.setAnimation(R.raw.email_verified);
                        verificationBinding.verificationStatusAnim.addAnimatorListener(new Animator.AnimatorListener() {
                            @Override
                            public void onAnimationStart(@NonNull Animator animation) {

                            }

                            @Override
                            public void onAnimationEnd(@NonNull Animator animation) {
                                verificationBinding.verificationStatusAnim.removeAllAnimatorListeners();
                                startActivity(new Intent(VerificationActivity.this, SuccessActivity.class));
                                finish();
                            }

                            @Override
                            public void onAnimationCancel(@NonNull Animator animation) {

                            }

                            @Override
                            public void onAnimationRepeat(@NonNull Animator animation) {

                            }
                        });
                    } else {
                        handler.postDelayed(this, 2500); // Check every 2.5 seconds
                    }
                });
            }
        };
        handler.post(runnable);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (handler != null && runnable != null) {
            handler.removeCallbacks(runnable);
        }
    }
}

/*
private void sendVerificationCode(String phoneNumber) {
        PhoneAuthOptions options = PhoneAuthOptions.newBuilder(mAuth)
                .setPhoneNumber(phoneNumber)
                .setTimeout(60L, TimeUnit.SECONDS)
                .setActivity(this)
                .setCallbacks(mCallbacks)
                .build();
        PhoneAuthProvider.verifyPhoneNumber(options);
    }

    private final PhoneAuthProvider.OnVerificationStateChangedCallbacks mCallbacks = new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
        @Override
        public void onVerificationCompleted(PhoneAuthCredential credential) {
            signInWithPhoneAuthCredential(credential);
        }

        @Override
        public void onVerificationFailed(FirebaseException e) {
            verificationBinding.verificationText.setText("Phone verification failed: " + e.getMessage());
        }

        @Override
        public void onCodeSent(String verificationId, PhoneAuthProvider.ForceResendingToken token) {
            mVerificationId = verificationId;
            mResendToken = token;
            verificationBinding.verificationText.setText("Code sent to your phone number.");
        }
    };

    private void verifyCode(String code) {
        PhoneAuthCredential credential = PhoneAuthProvider.getCredential(mVerificationId, code);
        signInWithPhoneAuthCredential(credential);
    }

    private void signInWithPhoneAuthCredential(PhoneAuthCredential credential) {
        mAuth.signInWithCredential(credential).addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                verificationBinding.verificationStatusAnim.setAnimation(R.raw.otp_verification);
                verificationBinding.verificationText.setText("Phone number verified successfully.");
            } else {
                if (task.getException() instanceof FirebaseAuthInvalidCredentialsException) {
                    verificationBinding.verificationText.setText("Invalid verification code.");
                }
            }
        });
    }


 */