package com.sistra.activities;

import android.content.Intent;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.sistra.R;
import com.sistra.databinding.ActivityEmailPasswordLoginBinding;

public class EmailPasswordLoginActivity extends AppCompatActivity {

    private ActivityEmailPasswordLoginBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityEmailPasswordLoginBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.registerContainer.setOnClickListener(v->{
            startActivity(new Intent(this, RegisterActivity.class));
        });
    }
}