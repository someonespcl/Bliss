package com.sistra.activities;

import android.animation.Animator;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.daimajia.androidanimations.library.Techniques;
import com.daimajia.androidanimations.library.YoYo;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseAuthInvalidUserException;
import com.google.firebase.auth.FirebaseAuthUserCollisionException;
import com.google.firebase.auth.FirebaseAuthWeakPasswordException;
import com.google.firebase.auth.FirebaseUser;
import com.sistra.R;
import com.sistra.utility.ComplimentGeneratorUtil;
import com.sistra.utility.DetailsValidatorUtil;
import com.sistra.databinding.ActivityRegisterBinding;

import java.util.Objects;

public class RegisterActivity extends AppCompatActivity {

    private ActivityRegisterBinding binding;

    private FirebaseAuth mAuth;
    private Vibrator vibrator;

    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityRegisterBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        //vibrator service
        vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);

        //initialize firebase auth
        mAuth = FirebaseAuth.getInstance();

        //close button
        binding.closeActivity.setOnClickListener(close -> getOnBackPressedDispatcher().onBackPressed());


        //username real time validation must be in small letters also it can have ., _, numbers and it must be minimum of 3 to 20
        binding.registerUserName.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String userName = s.toString().trim();
                if (userName.isEmpty() || !DetailsValidatorUtil.isValidUsername(userName)) {
                    vibrateOnError(binding.registerUserName);
                    binding.cuteTextContainer.setVisibility(View.GONE);
                    binding.registerUserName.setCompoundDrawablesRelativeWithIntrinsicBounds(0, 0, R.drawable.wrong, 0);
                } else {
                    binding.cuteTextContainer.setVisibility(View.VISIBLE);
                    binding.cuteTextDiscription.setText(ComplimentGeneratorUtil.getRandomDescription(userName));
                    binding.registerUserName.setCompoundDrawablesRelativeWithIntrinsicBounds(0, 0, R.drawable.checkmark, 0);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });

        //email address realtime validation will be allow only original emails
        binding.registerUserEmail.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String email = s.toString().trim();
                if (email.isEmpty() || !DetailsValidatorUtil.isValidEmail(email)) {
                    binding.registerUserEmail.setCompoundDrawablesRelativeWithIntrinsicBounds(0, 0, R.drawable.wrong, 0);
                } else {
                    binding.registerUserEmail.setCompoundDrawablesRelativeWithIntrinsicBounds(0, 0, R.drawable.checkmark, 0);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        //phone number validator only for indian number starts from 6, 7, 8, 9
        binding.registerUserPhoneNumber.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String phoneNumber = s.toString().trim();
                if (phoneNumber.isEmpty() || !DetailsValidatorUtil.isValidIndianPhoneNumber(phoneNumber)) {
                    binding.registerUserPhoneNumber.setCompoundDrawablesRelativeWithIntrinsicBounds(0, 0, R.drawable.wrong, 0);
                } else {
                    binding.registerUserPhoneNumber.setCompoundDrawablesRelativeWithIntrinsicBounds(0, 0, R.drawable.checkmark, 0);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        //password viewer
        Objects.requireNonNull(binding.registerUserPassword).setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_UP) {
                if (event.getRawX() >= (binding.registerUserPassword.getRight()
                        - binding.registerUserPassword.getCompoundDrawables()[2].getBounds().width())) {
                    boolean isPasswordVisible = !(binding.registerUserPassword
                            .getTransformationMethod() instanceof PasswordTransformationMethod);
                    binding.registerUserPassword
                            .setTransformationMethod(isPasswordVisible ? PasswordTransformationMethod.getInstance()
                                    : HideReturnsTransformationMethod.getInstance());
                    binding.registerUserPassword.setCompoundDrawablesRelativeWithIntrinsicBounds(0, 0,
                            isPasswordVisible ? R.drawable.eye_off : R.drawable.eye_on, 0);
                    binding.registerUserPassword.setSelection(binding.registerUserPassword.length());
                    return true;
                }
            }
            return false;
        });

        //password must contain At least one lowercase, one uppercase, one digit, one special character, and minimum 8 characters
        binding.registerUserPassword.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String password = s.toString().trim();
                if (password.isEmpty()) {
                    vibrateOnError(binding.registerUserPassword);
                    binding.errorTextContainer.setVisibility(View.VISIBLE);
                } else {
                    StringBuilder errorMessage = getStringBuilder(password);
                    if (errorMessage.length() > 0) {
                        binding.errorText.setText(errorMessage.toString());
                    } else {
                        binding.errorTextContainer.setVisibility(View.GONE);
                    }
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        //check details once again before entering it to the database
        binding.createAccount.setOnClickListener(createAccount -> {
            validateDetails();
        });

    }

    private void validateDetails() {
        String userName = binding.registerUserName.getText().toString().trim();
        String email = binding.registerUserEmail.getText().toString().trim();
        String phoneNumber = binding.registerUserPhoneNumber.getText().toString().trim();
        String password = binding.registerUserPassword.getText().toString().trim();

        //validate details
        if (!DetailsValidatorUtil.isValidUsername(userName)) {
            vibrateOnError(binding.registerUserName);
            binding.registerUserName.setCompoundDrawablesRelativeWithIntrinsicBounds(0, 0, R.drawable.wrong, 0);
            return;
        }

        if (!DetailsValidatorUtil.isValidEmail(email)) {
            vibrateOnError(binding.registerUserEmail);
            binding.registerUserEmail.setCompoundDrawablesRelativeWithIntrinsicBounds(0, 0, R.drawable.wrong, 0);
            return;
        }

        if (!DetailsValidatorUtil.isValidIndianPhoneNumber(phoneNumber)) {
            vibrateOnError(binding.registerUserPhoneNumber);
            binding.registerUserPhoneNumber.setCompoundDrawablesRelativeWithIntrinsicBounds(0, 0, R.drawable.wrong, 0);
            return;
        }

        if (!DetailsValidatorUtil.isValidPassword(password)) {
            vibrateOnError(binding.registerUserPassword);
            binding.registerUserPassword.setCompoundDrawablesRelativeWithIntrinsicBounds(0, 0, R.drawable.wrong, 0);
            return;
        }

        //enter the user details to the database
        createUserWithEmail(email, password, phoneNumber);
    }

    //it will create user with email and password
    private void createUserWithEmail(String email, String password, String phoneNumber) {
        //enable loading animation
        binding.createAccount.setText(null);
        binding.loadingAnim.setVisibility(View.VISIBLE);
        //create user with email password
        mAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Sign in success, update UI with the signed-in user's information
                            FirebaseUser user = mAuth.getCurrentUser();
                            binding.loadingAnim.setAnimation(R.raw.success);
                            binding.loadingAnim.addAnimatorListener(new Animator.AnimatorListener() {
                                @Override
                                public void onAnimationStart(@NonNull Animator animation) {

                                }

                                @Override
                                public void onAnimationEnd(@NonNull Animator animation) {
                                    binding.loadingAnim.removeAllAnimatorListeners();
                                    if (user != null && !user.isEmailVerified()) {
                                        Intent intent = new Intent(RegisterActivity.this, VerificationActivity.class);
                                        intent.putExtra("email", email);
                                        startActivity(intent);
                                        finish();

                                    } else if (user != null && user.isEmailVerified()) {
                                        Toast.makeText(RegisterActivity.this, "User email is already verified", Toast.LENGTH_LONG).show();
                                        startActivity(new Intent(RegisterActivity.this, SuccessActivity.class));
                                        finish();
                                    } else {
                                    }
                                }

                                @Override
                                public void onAnimationCancel(@NonNull Animator animation) {

                                }

                                @Override
                                public void onAnimationRepeat(@NonNull Animator animation) {

                                }
                            });
                        } else {
                            // If sign in fails, set back button state to normal
                            binding.loadingAnim.setVisibility(View.GONE);
                            binding.createAccount.setText(R.string.create_account);

                            Exception e = task.getException();
                            if (e != null) {
                                if (e instanceof FirebaseAuthInvalidCredentialsException) {
                                    Toast.makeText(RegisterActivity.this, "Invalid email or password.", Toast.LENGTH_SHORT).show();
                                } else if (e instanceof FirebaseAuthUserCollisionException) {
                                    Toast.makeText(RegisterActivity.this, "This email is already registered.", Toast.LENGTH_SHORT).show();
                                } else if (e instanceof FirebaseAuthInvalidUserException) {
                                    Toast.makeText(RegisterActivity.this, "Invalid user account.", Toast.LENGTH_SHORT).show();
                                } else {
                                    Toast.makeText(RegisterActivity.this, "Authentication failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                                }
                            }
                        }
                    }
                });
    }

    //it returns the error message for the password
    @NonNull
    private static StringBuilder getStringBuilder(String password) {
        StringBuilder errorMessage = new StringBuilder();

        if (!password.matches(".*[a-z].*")) {
            errorMessage.append("• At least one lowercase letter.+");
        }
        if (!password.matches(".*[A-Z].*")) {
            errorMessage.append("• At least one uppercase letter.");
        }
        if (!password.matches(".*\\d.*")) {
            errorMessage.append("• At least one digit.");
        }
        if (!password.matches(".*[@#$%^&+=!].*")) {
            errorMessage.append("• At least one special character.");
        }
        if (password.length() < 8) {
            errorMessage.append("• Minimum 8 characters required.");
        }
        return errorMessage;
    }

    //when ever user enters invalid details it will vibrate and shake
    private void vibrateOnError(View obj) {
        if (vibrator != null && vibrator.hasVibrator()) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                YoYo.with(Techniques.Shake).duration(700).playOn(obj);
                vibrator.vibrate(VibrationEffect.createOneShot(128, VibrationEffect.DEFAULT_AMPLITUDE));
            } else {
                YoYo.with(Techniques.Shake).duration(700).playOn(obj);
                vibrator.vibrate(128);
            }
        }
    }
}
