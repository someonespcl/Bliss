package com.sistra.utility;

import java.util.Random;

public class ComplimentGeneratorUtil {

    //LIST OF COMPLIMENTS
    private static final String[] COMPLIMENTS = {
            "%s has a heart so kind.",
            "%s is a true gem.",
            "%s shines bright.",
            "%s is simply amazing.",
            "%s brings joy wherever they go.",
            "%s is a ray of positivity.",
            "%s is a star.",
            "%s is awesome.",
            "%s is pure joy.",
            "%s is lovely.",
            "%s is a gem.",
            "%s is magical."
    };

    private static final Random RANDOM = new Random();

    // Method to get a random COMPLIMENT
    public static String getRandomDescription(String userName) {
        int index = RANDOM.nextInt(COMPLIMENTS.length);
        return String.format(COMPLIMENTS[index], userName);
    }
}
