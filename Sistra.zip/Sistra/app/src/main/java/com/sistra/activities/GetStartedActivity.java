package com.sistra.activities;

import static android.app.PendingIntent.getActivity;
import static android.content.ContentValues.TAG;

import android.animation.Animator;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.util.Log;
import android.util.Patterns;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.IntentSenderRequest;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.daimajia.androidanimations.library.Techniques;
import com.daimajia.androidanimations.library.YoYo;
import com.google.android.gms.auth.api.identity.BeginSignInRequest;
import com.google.android.gms.auth.api.identity.BeginSignInResult;
import com.google.android.gms.auth.api.identity.Identity;
import com.google.android.gms.auth.api.identity.SignInClient;
import com.google.android.gms.auth.api.identity.SignInCredential;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.common.api.CommonStatusCodes;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.firebase.FirebaseNetworkException;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseAuthMultiFactorException;
import com.google.firebase.auth.FirebaseAuthUserCollisionException;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GoogleAuthProvider;
import com.sistra.R;
import com.sistra.databinding.ActivityGetStartedBinding;
import com.sistra.databinding.LoginSheetBinding;
import com.sistra.databinding.PhoneNumLoginSheetBinding;

import java.util.Objects;
import java.util.regex.Pattern;

public class GetStartedActivity extends AppCompatActivity {
    private ActivityGetStartedBinding binding;
    private LoginSheetBinding loginSheetBinding;
    private PhoneNumLoginSheetBinding phoneNumLoginSheetBinding;
    private BottomSheetDialog bottomSheetDialog, phoneNumberSheetDialog;
    private Vibrator vibrator;
    private FirebaseAuth mAuth;
    private BeginSignInRequest signInRequest;
    private static final int RC_SIGN_IN = 1411;
    private GoogleSignInClient mGoogleSignInClient;


    private SignInClient oneTapClient;
    private BeginSignInRequest signUpRequest;
    private static final int REQ_ONE_TAP = 2;  // Can be any integer unique to the Activity.
    private boolean showOneTapUI = true;

    private static final String EMAIL_REGEX =
            "^(?=.{1,64}@)" +                        // Max 64 chars for local part
                    "[a-zA-Z0-9](?!.*?[._%+-]{2})[a-zA-Z0-9._%+-]*[a-zA-Z0-9]" +
                    "@" +
                    "(?:[a-zA-Z0-9-]+\\.)?" +                // Subdomains allowed
                    "(?:gmail\\.com|yahoo\\.in|rediffmail\\.com|hotmail\\.com|outlook\\.com|" +
                    "[a-zA-Z0-9-]+\\.in|[a-zA-Z0-9-]+\\.co\\.in|" +
                    "[a-zA-Z0-9-]+\\.gov\\.in|[a-zA-Z0-9-]+\\.edu\\.in|" +
                    "[a-zA-Z0-9-]+\\.ac\\.in)" +
                    "$";
    // Top-level domain of at least two letters
    private static final Pattern EMAIL_PATTERN = Pattern.compile(EMAIL_REGEX);


    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);

        mAuth = FirebaseAuth.getInstance();

        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(getString(R.string.default_web_client_id)).requestEmail().build();

        mGoogleSignInClient = GoogleSignIn.getClient(this, gso);


        oneTapClient = Identity.getSignInClient(this);
        signUpRequest = BeginSignInRequest.builder()
                .setGoogleIdTokenRequestOptions(BeginSignInRequest.GoogleIdTokenRequestOptions.builder()
                        .setSupported(true)
                        // Your server's client ID, not your Android client ID.
                        .setServerClientId(getString(R.string.client_id))
                        // Show all accounts on the device.
                        .setFilterByAuthorizedAccounts(false)
                        .build())
                .build();


        ActivityResultLauncher<IntentSenderRequest> activityResultLauncher =
                registerForActivityResult(new ActivityResultContracts.StartIntentSenderForResult(), new ActivityResultCallback<ActivityResult>() {
                    @Override
                    public void onActivityResult(ActivityResult result) {
                        try {
                            SignInCredential credential = oneTapClient.getSignInCredentialFromIntent(result.getData());
                            String idToken = credential.getGoogleIdToken();
                            if (idToken !=  null) {
                                // Got an ID token from Google. Use it to authenticate
                                // with your backend.
                                String email = credential.getId();
                                String username = credential.getDisplayName();
                                startActivity(new Intent(GetStartedActivity.this, SuccessActivity.class));
                                finish();
                            }
                        } catch (ApiException e) {
                            e.printStackTrace();
                        }
                    }
                });

        binding = ActivityGetStartedBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        bottomSheetDialog = new BottomSheetDialog(GetStartedActivity.this);
        phoneNumberSheetDialog = new BottomSheetDialog(GetStartedActivity.this);
        loginSheetBinding = LoginSheetBinding.inflate(getLayoutInflater());
        bottomSheetDialog.setContentView(loginSheetBinding.getRoot());
        phoneNumLoginSheetBinding = PhoneNumLoginSheetBinding.inflate(getLayoutInflater());
        phoneNumberSheetDialog.setContentView(phoneNumLoginSheetBinding.getRoot());

        loginSheetBinding.registerContainer.setOnClickListener(v->{
            startActivity(new Intent(GetStartedActivity.this, RegisterActivity.class));
        });

        binding.getStartedBtn.setOnClickListener(show -> {
            phoneNumberSheetDialog.show();
            phoneNumberSheetDialog.setCanceledOnTouchOutside(false);

            phoneNumLoginSheetBinding.close.setOnClickListener(close1 -> {
                phoneNumberSheetDialog.dismiss();
            });

            phoneNumLoginSheetBinding.goToSigninBtn.setOnClickListener(showSignInPage -> {
                //bottomSheetDialog.show();
                phoneNumberSheetDialog.dismiss();
                bottomSheetDialog.setCanceledOnTouchOutside(false);
                startActivity(new Intent(GetStartedActivity.this, EmailPasswordLoginActivity.class));

                loginSheetBinding.close.setOnClickListener(close -> {
                    bottomSheetDialog.dismiss();
                });

                loginSheetBinding.loginEmail.addTextChangedListener(new TextWatcher() {
                    @Override
                    public void beforeTextChanged(CharSequence arg0, int arg1, int arg2, int arg3) {
                    }

                    @Override
                    public void onTextChanged(CharSequence s, int start, int end, int count) {
                        String email = s.toString().trim();
                        if (!EMAIL_PATTERN.matcher(email).matches()) {
                            loginSheetBinding.loginEmail.setCompoundDrawablesRelativeWithIntrinsicBounds(0, 0, R.drawable.wrong, 0);
                            return;
                        }
                        loginSheetBinding.loginEmail.setCompoundDrawablesRelativeWithIntrinsicBounds(0, 0, R.drawable.checkmark, 0);
                    }

                    @Override
                    public void afterTextChanged(Editable arg0) {
                    }
                });
            });

            loginSheetBinding.loginPassword.setOnTouchListener((v, event) -> {
                if (event.getAction() == MotionEvent.ACTION_UP) {
                    if (event.getRawX() >= (loginSheetBinding.loginPassword.getRight()
                            - loginSheetBinding.loginPassword.getCompoundDrawables()[2].getBounds().width())) {
                        boolean isPasswordVisible = !(loginSheetBinding.loginPassword
                                .getTransformationMethod() instanceof PasswordTransformationMethod);
                        loginSheetBinding.loginPassword
                                .setTransformationMethod(isPasswordVisible ? PasswordTransformationMethod.getInstance()
                                        : HideReturnsTransformationMethod.getInstance());
                        loginSheetBinding.loginPassword.setCompoundDrawablesRelativeWithIntrinsicBounds(0, 0,
                                isPasswordVisible ? R.drawable.eye_off : R.drawable.eye_on, 0);
                        loginSheetBinding.loginPassword.setSelection(loginSheetBinding.loginPassword.length());
                        return true;
                    }
                }
                return false;
            });

            loginSheetBinding.signInBtn.setOnClickListener(validate -> {
                validateDetails();
            });

            phoneNumLoginSheetBinding.registerContainer.setOnClickListener(register -> {
                Intent intent = new Intent(getApplicationContext(), RegisterActivity.class);
                startActivity(intent);
                if (this != null) {
                    this.overridePendingTransition(R.anim.slide_in_up, R.anim.slide_in_down);
                }
            });
        });

        binding.continueWithGoogle.setOnClickListener(show -> {
            //signIn();
            oneTapClient.beginSignIn(signUpRequest)
                    .addOnSuccessListener(GetStartedActivity.this, new OnSuccessListener<BeginSignInResult>() {
                        @Override
                        public void onSuccess(BeginSignInResult result) {

                            IntentSenderRequest intentSenderRequest =
                                    new IntentSenderRequest.Builder(result.getPendingIntent().getIntentSender()).build();
                            activityResultLauncher.launch(intentSenderRequest);

                        }
                    })
                    .addOnFailureListener(GetStartedActivity.this, new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            // No Google Accounts found. Just continue presenting the signed-out UI.
                            Log.d("TAG", e.getLocalizedMessage());
                        }
                    });
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == RC_SIGN_IN) {
            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
            try {
                GoogleSignInAccount account = task.getResult(ApiException.class);
                firebaseAuthWithGoogle(account.getIdToken());
            } catch (ApiException e) {
                Toast.makeText(GetStartedActivity.this, e.getLocalizedMessage(), Toast.LENGTH_LONG).show();
            }
        }
    }

    private void firebaseAuthWithGoogle(String idToken) {
        AuthCredential credential = GoogleAuthProvider.getCredential(idToken, null);
        mAuth.signInWithCredential(credential).addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if (task.isSuccessful()) {
                    FirebaseUser firebaseUser = mAuth.getCurrentUser();
                } else {
                    String errorMessage;
                    try {
                        throw Objects.requireNonNull(task.getException());
                    } catch (FirebaseAuthInvalidCredentialsException e) {
                        errorMessage = "Invalid credentials. Please try again.";
                    } catch (FirebaseAuthUserCollisionException e) {
                        errorMessage = "An account already exists with the same email.";
                    } catch (FirebaseNetworkException e) {
                        errorMessage = "Network error. Please check your connection.";
                    } catch (FirebaseAuthMultiFactorException e) {
                        errorMessage = "Multi-factor authentication is required.";
                    } catch (Exception e) {
                        errorMessage = "Google sign-in failed. Please try again.";
                    }
                    Toast.makeText(GetStartedActivity.this, errorMessage, Toast.LENGTH_LONG).show();
                    binding.loadingAnim.setVisibility(View.GONE);
                    binding.continueWithGoogle.setText(getString(R.string.google_hint));
                    binding.continueWithGoogle.setIcon(getDrawable(R.drawable.google));
                }
            }
        });
    }

    private void signIn() {
        Intent signInIntent = mGoogleSignInClient.getSignInIntent();
        startActivityForResult(signInIntent, RC_SIGN_IN);
    }

    private void validateDetails() {
        String email = loginSheetBinding.loginEmail.getText().toString().trim();
        String password = loginSheetBinding.loginPassword.getText().toString().trim();

        if (email.isEmpty()) {
            vibrateOnError(loginSheetBinding.loginEmail);
            loginSheetBinding.loginEmail.setCompoundDrawablesRelativeWithIntrinsicBounds(0, 0, R.drawable.wrong, 0);
            return;
        }
        if (!EMAIL_PATTERN.matcher(email).matches()) {
            vibrateOnError(loginSheetBinding.loginEmail);
            loginSheetBinding.loginEmail.setCompoundDrawablesRelativeWithIntrinsicBounds(0, 0, R.drawable.wrong, 0);
            return;
        }
        if (password.isEmpty()) {
            vibrateOnError(loginSheetBinding.loginPassword);
            return;
        }
        if (password.length() < 6) {
            vibrateOnError(loginSheetBinding.loginPassword);
            return;
        }
    }
    private void vibrateOnError(View obj) {
        if (vibrator != null && vibrator.hasVibrator()) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                YoYo.with(Techniques.Shake).duration(700).playOn(obj);
                vibrator.vibrate(VibrationEffect.createOneShot(128, VibrationEffect.DEFAULT_AMPLITUDE));
            } else {
                YoYo.with(Techniques.Shake).duration(700).playOn(obj);
                vibrator.vibrate(128);
            }
        }
    }
}