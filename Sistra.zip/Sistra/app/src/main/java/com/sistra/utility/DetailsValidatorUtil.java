package com.sistra.utility;

import java.util.regex.Pattern;

public class DetailsValidatorUtil {

    // Username regex
    public static final String USERNAME_REGEX = "^[a-zA-Z0-9._]{3,20}$";

    //email regex
    private static final String EMAIL_REGEX =
            "^(?=.{1,64}@)" +                        // Max 64 chars for local part
                    "[a-zA-Z0-9](?!.*?[._%+-]{2})[a-zA-Z0-9._%+-]*[a-zA-Z0-9]" +
                    "@" +
                    "(?:[a-zA-Z0-9-]+\\.)?" +                // Subdomains allowed
                    "(?:gmail\\.com|yahoo\\.in|rediffmail\\.com|hotmail\\.com|outlook\\.com|" +
                    "[a-zA-Z0-9-]+\\.in|[a-zA-Z0-9-]+\\.co\\.in|" +
                    "[a-zA-Z0-9-]+\\.gov\\.in|[a-zA-Z0-9-]+\\.edu\\.in|" +
                    "[a-zA-Z0-9-]+\\.ac\\.in)" +
                    "$";
    private static final Pattern EMAIL_PATTERN = Pattern.compile(EMAIL_REGEX);

    // Indian phone number regex (10 digits starting with 6, 7, 8, or 9)
    public static final String INDIAN_PHONE_REGEX = "^[6-9]\\d{9}$";
    private static final Pattern PHONE_PATTERN = Pattern.compile(INDIAN_PHONE_REGEX);

    // Password regex (At least one lowercase, one uppercase, one digit, one special character, and minimum 8 characters)
    public static final String PASSWORD_REGEX = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@#$%^&+=!]).{8,}$";
    private static final Pattern PASSWORD_PATTERN = Pattern.compile(PASSWORD_REGEX);

    //username validator
    public static boolean isValidUsername(String userName) {
        return userName.matches(USERNAME_REGEX);
    }

    //email validator
    public static boolean isValidEmail(String email) {
        return EMAIL_PATTERN.matcher(email).matches();
    }

    public static boolean isValidIndianPhoneNumber(String phoneNumber) {
        return PHONE_PATTERN.matcher(phoneNumber).matches();
    }

    public static boolean isValidPassword(String password) {
        return PASSWORD_PATTERN.matcher(password).matches();
    }
}